

<div class="row ">
    <?php include('db/config.php'); ?>
    <div class="col-6">
        <a class="navbar-brand " href="index.php">
            <!-- <img src="img/neuronoidsimage.png" width="70px" height="auto" alt=""> -->
            <!-- <h3 class="pl-4 pb-2 pt-3">Skill Monks</h3> -->
            <img src="img/logo.png" width="130px" alt="">
            <!-- <strong>MDB</strong> -->
        </a></div>
    <div class="col-6 text-center">
        <div class="">
            <p class="text-dark head-mail font-weight-bolder pt-3 pt-lg-5 pt-md-5">
                Email : skillmonks@gmail.com &nbsp &nbsp Contact :
                9578 800 900

            </p>
        </div>
    </div>

</div>