<div class="skbg text-white">
        <div class="container">
            <div class="row">
                <div class="col text-center ">
                    <div>
                        <p class="m-0 p-3">Our Platform is Getting Launched Soon... Register Now and Get Early Mover Advantage</p>

                    </div>
                </div>
            </div>
        </div>
    </div>