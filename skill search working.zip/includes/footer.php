<footer class="page-footer text-center font-small wow fadeIn">
        <!--Copyright-->
        <div class="footer-copyright py-3">
            © 2019 Copyright:
            <a href="index.php" target="_blank">skillmonks.com </a>
            All Rights Reserved
        </div>

    </footer>