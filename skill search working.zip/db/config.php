<?php

$connection=mysqli_connect("localhost","root","","skillmonks");

if(!$connection)
{
die("Connection failed: " . mysqli_connect_error());
}else{

}

?>