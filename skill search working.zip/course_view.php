<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Skill Monks</title>
  <?php include('includes/links.php'); ?>
  <!-- <script type="text/javascript" src="jquery-1.11.3-jquery.min.js"></script> -->
  <style type="text/css">
    body {}

    /* html,
    body,
    header,
    .view {
      height: 100%;
    } */

    @media (max-width: 740px) {

      html,
      body,
      header,
      .view {
        height: 1300px;
      }
    }

    @media (min-width: 700px) and (max-width: 990px) {

      html,
      body,
      header,
      .view {
        height: 1200px;
      }
    }

    @media (min-width: 800px) and (max-width: 850px) {

      html,
      body,
      header,
      .view {
        height: 1200px;
      }
    }

    @media (min-width: 800px) and (max-width: 850px) {
      .navbar:not(.top-nav-collapse) {
        background: #1C2331 !important;
      }
    }

    .cus-tab-content>.active {
      display: flex;
    }

    body {
      background: #e0e0e0;
    }

    a:hover {
      color: black;
    }
  </style>
</head>

<body>
  <script>
    $(document).ready(function() {
      load_data();

      function load_data(query) {
        $.ajax({
          url: "tab_search.php",
          method: "POST",
          data: {
            query: query
          },
          success: function(data) {
            $('#result').html(data);
          }
        });
      }
      $('#search').keyup(function() {
        var search = $(this).val();
        if (search != '') {
          load_data(search);
        } else {
          load_data();
        }
      });
    });
  </script>


  <!-- Navbar -->

  <!-- Full Page Intro -->

  <div class="container mb-4">
    <?php include('includes/header.php'); ?>
  </div>
  <div class="container mb-3">
    <!-- <button type="button" class=" btn modelbutton" data-toggle="modal" data-target="#basicExampleModal">
      Launch demo modal
    </button> -->
    <div class="row">
      <div class="col-12">
        <ul class="nav nav-tabs cus-s-tabs" id="myTab" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="all-tab" data-toggle="tab" href="#all" role="tab" aria-controls="contact" aria-selected="false">All Courses</a>
          </li>
          <?php
          $query = "SELECT * FROM course_tab";
          $query_run = mysqli_query($connection, $query);
          ?>
          <?php
          if (mysqli_num_rows($query_run) > 0) {
            while ($row = mysqli_fetch_assoc($query_run)) {
              ?>
              <li class="nav-item">
                <a class="nav-link" id="<?php echo $row['course_id']; ?>-tab" data-toggle="tab" href="#<?php echo $row['course_id']; ?>" role="tab" aria-controls="<?php echo $row['course']; ?>" aria-selected="false"><?php echo $row['course']; ?></a>
              </li>
            <?php
            }
          } else {
            echo "No record found";
          }
          ?>
          <li class="nav-item">
            <a class="nav-link" id="multi-tab" data-toggle="tab" href="#multi" role="tab" aria-controls="multi" aria-selected="false">Multimedia</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="sap-tab" data-toggle="tab" href="#sap" role="tab" aria-controls="sap" aria-selected="false">SAP</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="cyber-tab" data-toggle="tab" href="#cyber" role="tab" aria-controls="cyber" aria-selected="false">Cyber Security</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="web-tab" data-toggle="tab" href="#web" role="tab" aria-controls="web" aria-selected="false">Web Designing</a>
          </li>
          <li class="nav-item ml-auto">
            <input style="margin-top:1px;border-radius:15px" type="text" name="search" id="search" placeholder="Search" autocomplete="off" class="form-control" />
          </li>

        </ul>
      </div>

    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col">
        <h2 class="h2-responsive text-center">Upcoming Batches.</h2>
      </div>
    </div>
  </div>
  <div class="container tab-content cus-tab-content mt-3" id="myTabContent">
    <div class="row tab-pane fade show  active" id="all" role="tabpanel" aria-labelledby="all-tab">
      <?php
      $rec_limit = 28;
      $sql = "SELECT count(id) FROM institute_data";
      $retval = mysqli_query($connection, $sql);
      if (!$retval) {
        die('Could not get data: ' . mysql_error());
      }
      $row = mysqli_fetch_array($retval, MYSQLI_NUM);
      $rec_count = $row[0];
      if (isset($_GET{
        'page'})) {
        $page = $_GET{
          'page'} + 1;
        $offset = $rec_limit * $page;
      } else {
        $page = 0;
        $offset = 0;
      }
      $left_rec = $rec_count - ($page * $rec_limit);
      $sql = "SELECT * " .
        "FROM institute_data ORDER BY batch_date DESC " .
        "LIMIT $offset, $rec_limit ";
      $retval = mysqli_query($connection, $sql);
      if (!$retval) {
        die('Could not get data: ' . mysql_error());
      }
      while ($row = mysqli_fetch_array($retval, MYSQLI_ASSOC)) {
        $image = (!empty($row['photo'])) ? 'img/' . $row['photo'] : 'img/jav.jpg';
        $course = $row['course'];
        $institute = $row['institute'];
        $location = $row['location'];
        $batch_date = $row['batch_date'];
        echo "
        <div class='row' id='result' ></div>

  ";
      }
      echo " <div class='container'><div class='col-12'>
    <div class='text-center'> ";
      if ($page > 0) {
        $last = $page - 2;
        echo "<a href=\"$_SERVER[PHP_SELF]?page=$last\"><button class='btn btn-rounded skbg'>Previous</button></a> ";
        echo "<a href=\"$_SERVER[PHP_SELF]?page=$page\"><button class='btn btn-rounded skbg'>Next</button></a>";
      } else if ($page == 0) {
        echo "<a href=\"$_SERVER[PHP_SELF]?page=$page\"><button class='btn btn-rounded skbg'>Next</button></a>";
      } else if ($left_rec < $rec_limit) {
        $last = $page - 2;
        echo "<a href = \"$_SERVER[PHP_SELF]?page=$last\"><button class='btn btn-rounded skbg'>Last</button></a>";
      }

      echo "</div></div></div> "
      ?>
    </div>
    <?php
    $query = "SELECT * FROM course_tab";
    $query_run = mysqli_query($connection, $query);
    ?>
    <?php
    if (mysqli_num_rows($query_run) > 0) {
      while ($row = mysqli_fetch_assoc($query_run)) {
        ?>
        <div class="row tab-pane fade show" id="<?php echo $row['course_id']; ?>" role="tabpanel" aria-labelledby="<?php echo $row['course_id']; ?>-tab">
          <?php
          $selected = $row['course'];
          $search_exploded = explode(" ", $selected);
          $x = 0;
          $construct = "";
          foreach ($search_exploded as $search_each) {
            $x++;
            if ($x == 1) $construct .= "course LIKE '%$search_each%'";
            else $construct .= "OR institute LIKE '%$search_each%'";
          }

          $querys = "SELECT * FROM institute_data WHERE $construct ORDER BY batch_date DESC ";
          $querys_run = mysqli_query($connection, $querys);
          ?>
          <?php
          if (mysqli_num_rows($querys_run) > 0) {
            while ($row = mysqli_fetch_assoc($querys_run)) {
              $image = (!empty($row['photo'])) ? 'img/' . $row['photo'] : 'img/jav.jpg';
              ?>
              <div class="col-lg-3 col-md-4 col-sm-6 mb-lg-0 mb-4 card-head fadeIn animated">
                <div class="row  card-course h-95 mb-0 pt-0">
                  <!-- Featured image -->
                  <div class="">
                    <div class=" overlay rounded  mb-2 mt-0">
                      <img class="img-fluid w-100" width="100%" src="<?php echo $image ?>" alt="Sample image">
                      <a>
                        <div class="mask rgba-white-slight"></div>
                      </a>
                    </div>
                  </div>
                  <div class="pt-2 pr-2 pl-2">
                    <!-- Category -->
                    <a href="#!" class="">
                      <p class="font-weight-bold mb-1 skc"><i class="fas fa-map pr-2"></i><?php echo $row['course']; ?></p>
                    </a>
                    <!-- Post title -->
                    <h5 class=" mb-1"><strong><?php echo $row['institute']; ?></strong></h5>
                    <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Location: </a><?php echo $row['location']; ?></p>
                    <!-- Post data -->
                    <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Batch Date: </a><?php echo $row['batch_date']; ?></p>
                    <!-- Excerpt -->
                    <p class="dark-grey-text small p-2"> </p>
                    <!-- Read more button -->
                  </div>
                </div>
              </div>
            <?php
            }
          } else {
            echo "No record found";
          }
          ?>
        </div>
      <?php
      }
    } else {
      echo "No record found";
    }
    ?>
    <div class="row tab-pane fade" id="multi" role="tabpanel" aria-labelledby="multi-tab">
      <?php
      $selected = 'multimedia';
      $query = "SELECT * FROM institute_data WHERE (course LIKE '%$selected%') OR (institute LIKE '%$selected%')";
      $query_run = mysqli_query($connection, $query);
      ?>
      <?php
      if (mysqli_num_rows($query_run) > 0) {
        while ($row = mysqli_fetch_assoc($query_run)) {
          $image = (!empty($row['photo'])) ? 'img/' . $row['photo'] : 'img/jav.jpg';
          ?>
          <div class="col-lg-3 col-md-12 mb-lg-0 mb-4 card-head fadeIn animated">
            <div class="row  card-course h-95 mb-0 pt-0">
              <!-- Featured image -->
              <div class="">
                <div class=" overlay rounded  mb-2 mt-0">
                  <img class="img-fluid" src="<?php echo $image ?>" alt="Sample image">
                  <a>
                    <div class="mask rgba-white-slight"></div>
                  </a>
                </div>
              </div>
              <div class="p-2">
                <!-- Category -->
                <a href="#!" class="">
                  <p class="font-weight-bold mb-1 skc"><i class="fas fa-map pr-2"></i><?php echo $row['course']; ?></p>
                </a>
                <!-- Post title -->
                <h5 class=" mb-1"><strong><?php echo $row['institute']; ?></strong></h5>
                <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Location: </a><?php echo $row['location']; ?></p>
                <!-- Post data -->
                <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Batch Date: </a><?php echo $row['batch_date']; ?></p>
                <!-- Excerpt -->
                <p class="dark-grey-text small p-2"></p>
                <!-- Read more button -->
              </div>
            </div>
          </div>
        <?php
        }
      } else {
        echo "No record found";
      }
      ?>
    </div>
    <div class="row tab-pane fade" id="sap" role="tabpanel" aria-labelledby="sap-tab">
      <?php
      $selected = 'sap';
      $query = "SELECT * FROM institute_data WHERE (course LIKE '%$selected%') OR (institute LIKE '%$selected%')";
      $query_run = mysqli_query($connection, $query);
      ?>
      <?php
      if (mysqli_num_rows($query_run) > 0) {
        while ($row = mysqli_fetch_assoc($query_run)) {
          $image = (!empty($row['photo'])) ? 'img/' . $row['photo'] : 'img/jav.jpg';
          ?>
          <div class="col-lg-3 col-md-12 mb-lg-0 mb-4 card-head fadeIn animated">
            <div class="row  card-course h-95 mb-0 pt-0">
              <!-- Featured image -->
              <div class="">
                <div class=" overlay rounded  mb-2 mt-0">
                  <img class="img-fluid" src="<?php echo $image ?>" alt="Sample image">
                  <a>
                    <div class="mask rgba-white-slight"></div>
                  </a>
                </div>
              </div>
              <div class="p-2">
                <!-- Category -->
                <a href="#!" class="">
                  <p class="font-weight-bold mb-1 skc"><i class="fas fa-map pr-2"></i><?php echo $row['course']; ?></p>
                </a>
                <!-- Post title -->
                <h5 class=" mb-1"><strong><?php echo $row['institute']; ?></strong></h5>
                <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Location: </a><?php echo $row['location']; ?></p>
                <!-- Post data -->
                <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Batch Date: </a><?php echo $row['batch_date']; ?></p>
                <!-- Excerpt -->
                <p class="dark-grey-text small p-2"> </p>
                <!-- Read more button -->
              </div>
            </div>
          </div>
        <?php
        }
      } else {
        echo "No record found";
      }
      ?>
    </div>
    <div class="row tab-pane fade" id="cyber" role="tabpanel" aria-labelledby="cyber-tab">
      <?php
      $selected = 'Hacking';
      $query = "SELECT * FROM institute_data WHERE (course LIKE '%$selected%') OR (institute LIKE '%$selected%')";
      $query_run = mysqli_query($connection, $query);
      ?>
      <?php
      if (mysqli_num_rows($query_run) > 0) {
        while ($row = mysqli_fetch_assoc($query_run)) {
          $image = (!empty($row['photo'])) ? 'img/' . $row['photo'] : 'img/jav.jpg';
          ?>
          <div class="col-lg-3 col-md-12 mb-lg-0 mb-4 card-head fadeIn animated">
            <div class="row  card-course h-95 mb-0 pt-0">
              <!-- Featured image -->
              <div class="">
                <div class=" overlay rounded  mb-2 mt-0">
                  <img class="img-fluid" src="<?php echo $image ?>" alt="Sample image">
                  <a>
                    <div class="mask rgba-white-slight"></div>
                  </a>
                </div>
              </div>
              <div class="p-2">
                <!-- Category -->
                <a href="#!" class="">
                  <p class="font-weight-bold mb-1 skc"><i class="fas fa-map pr-2"></i><?php echo $row['course']; ?></p>
                </a>
                <!-- Post title -->
                <h5 class=" mb-1"><strong><?php echo $row['institute']; ?></strong></h5>
                <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Location: </a><?php echo $row['location']; ?></p>
                <!-- Post data -->
                <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Batch Date: </a><?php echo $row['batch_date']; ?></p>
                <!-- Excerpt -->
                <p class="dark-grey-text small p-2"> </p>
                <!-- Read more button -->
              </div>
            </div>
          </div>
        <?php
        }
      } else {
        echo "No record found";
      }
      ?>
    </div>
    <div class="row tab-pane fade" id="web" role="tabpanel" aria-labelledby="web-tab">
      <?php
      $selected = 'web';
      $query = "SELECT * FROM institute_data WHERE (course LIKE '%$selected%') OR (institute LIKE '%$selected%')";
      $query_run = mysqli_query($connection, $query);
      ?>
      <?php
      if (mysqli_num_rows($query_run) > 0) {
        while ($row = mysqli_fetch_assoc($query_run)) {
          $image = (!empty($row['photo'])) ? 'img/' . $row['photo'] : 'img/jav.jpg';
          ?>
          <div class="col-lg-3 col-md-12 mb-lg-0 mb-4 card-head fadeIn animated">
            <div class="row  card-course h-95 mb-0 pt-0">
              <!-- Featured image -->
              <div class="">
                <div class=" overlay rounded  mb-2 mt-0">
                  <img class="img-fluid" src="<?php echo $image ?>" alt="Sample image">
                  <a>
                    <div class="mask rgba-white-slight"></div>
                  </a>
                </div>
              </div>
              <div class="p-2">
                <!-- Category -->
                <a href="#!" class="">
                  <p class="font-weight-bold mb-1 skc"><i class="fas fa-map pr-2"></i><?php echo $row['course']; ?></p>
                </a>
                <!-- Post title -->
                <h5 class=" mb-1"><strong><?php echo $row['institute']; ?></strong></h5>
                <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Location: </a><?php echo $row['location']; ?></p>
                <!-- Post data -->
                <p class="mb-1 small"><a href="#!" class="font-weight-bold skc">Batch Date: </a><?php echo $row['batch_date']; ?></p>
                <!-- Excerpt -->
                <p class="dark-grey-text small p-2"> </p>
                <!-- Read more button -->
              </div>
            </div>
          </div>
        <?php
        }
      } else {
        echo "No record found";
      }
      ?>
    </div>
  </div>



  <!-- Full Page Intro -->
  <!--Footer-->
  <?php include('includes/footer.php'); ?>
  <!-- modal -->
  <!-- Modal -->
  <!-- add class dis -->


  <script>
    $(function() {
      $("#mdb-lightbox-ui").load("mdb-addons/mdb-lightbox-ui.html");
    });
  </script>
  <!--/.Footer-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <?php include('includes/scripts.php'); ?>

</body>

</html>